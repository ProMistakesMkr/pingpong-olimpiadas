import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;

public class Principal extends PApplet {

	public static void main(String[] args) {
		PApplet.main("Principal");

	}

	public void settings() {
		size(500, 500);
	}

	int[][] lineas;
	ArrayList<CarroAmarillo> carritos;
	CarritoRojo cRojo; //instancia para carrito rojo
	CarroAmarillo cAmar;

	public void setup() {
		cRojo = new CarritoRojo(25,250); //declarada la instancia para carrito rojo
		lineas = new int[8][4]; // 1ro filas 2do columnas
		cAmar = new CarroAmarillo();

		for (int f = 0; f < 8; f++) { // l�neas de la calle
			for (int c = 0; c < 4; c++) {
				lineas[f][c] = 0;
			}
		} // cierre for

		carritos = new ArrayList<CarroAmarillo>();//carros en movimiento
		for (int i = 0; i < 5; i++) {
			carritos.add(new CarroAmarillo());
			
		}
	}

	public void draw() {
		background(77, 185, 22);
		fill(131, 131, 131);
		noStroke();
		rect(50, 0, 400, 500);
		rect(0, 210, 500, 80);
		
		for (int f = 0; f < 8; f++) { //calle
			for (int c = 0; c < 4; c++) {

				int px = 135 + (c * 80);
				int py = 0 + (f * 80);
				fill(255);
				rectMode(CENTER);
				rect(px, py, 8, 25);
				rectMode(CORNER);
			}
		}		
		for(CarroAmarillo losCarros : carritos) {//amarillos
			losCarros.pintar(this);
			losCarros.mover();
			if(dist( cAmar.getX(), cAmar.getY(), cRojo.getX(), cRojo.getY())<10) {
			cRojo.xC=25;
			}
			}
		
		cRojo.pintar(this);	//Llamo al metodo pintar de la clase carritoRojo
		
		
	if(frameCount%300==0){
		carritos.add(new CarroAmarillo());
		}	
}
	
	public void keyPressed() {
		cRojo.keypressed(this);//llamo al metodo keypressed de la clase carritoRojo
	}
	
}