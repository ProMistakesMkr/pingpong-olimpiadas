import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PConstants;

public class CarroAmarillo {
	int x, y;
	int velocidad;

	public CarroAmarillo() {
		this.y= y;
		int carril = (int) (Math.random() * 10);
		velocidad = 3;
		this.x = 85;
		//x = 80 + (2 * carril);
	}

	public void pintar(PApplet app) {
		app.fill(254, 225, 63);
		app.rectMode(PConstants.CENTER);
		app.noStroke();
		app.rect(x, y, 30, 50);
		app.rectMode(PConstants.CORNER);

	}	
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}

	public void mover() {
		y += velocidad;
		if (y > 500) {
			y = 0;
			x += 85;
		}
		if (x > 450) {
            x = 85;
        }
	}

}