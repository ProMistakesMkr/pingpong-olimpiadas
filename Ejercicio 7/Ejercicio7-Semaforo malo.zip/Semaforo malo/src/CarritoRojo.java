
import processing.core.PApplet;
import processing.core.PConstants;

public class CarritoRojo {
	int xC, yC;
	int velocidad;

	public CarritoRojo(int xC, int yC) {
		this.xC = 25;
		this.yC= 250;
	}
	
	public void pintar(PApplet app) {
		app.fill(255,0,0);
		app.rectMode(PConstants.CENTER);
		app.noStroke();
		app.rect(xC, yC, 50, 30);
		app.rectMode(PConstants.CORNER);
		
	}
	
	public int getX() {
		return xC;
	}

	public int getY() {
		return yC;
	}
	
	public void keypressed(PApplet app) {
		switch (app.key) {
		case 'd':
			xC+=77;
			break;
		
		case 'a':
			xC-=77;
			break;
		}
	}
}
