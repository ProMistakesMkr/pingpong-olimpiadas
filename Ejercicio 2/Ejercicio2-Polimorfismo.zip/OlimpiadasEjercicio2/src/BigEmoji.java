import processing.core.PApplet;
import processing.core.PImage;

public class BigEmoji{

	int x,y;
	float x1,y1;
	PImage Enojado;
	PImage Enamorado;
	PImage Divertido;
	PImage Triste;
	PImage Sorprendido;
	
	public BigEmoji (PApplet app) {//Constructor
	this.Enojado=app.loadImage ("Enojado.png");
	this.Enamorado=app.loadImage ("Enamorado.png");
	this.Divertido=app.loadImage ("Divertido.png");
	this.Triste=app.loadImage ("Triste.png");
	this.Sorprendido=app.loadImage ("Sorprendido.png");
	
	this.x=210;
	this.y=200;
	this.x1=200;
	this.y1=200;
	}
	
	public void pintar(PApplet app) {				//Pintar1
		(Enojado).resize(100, 100);
		app.image (Enojado,x-10,y-120);
	}
	
	public void pintar(PApplet app,int x, int y) {	//Pintar 2
		(Enamorado).resize(100, 100);
		app.image (Enamorado,x,y-50);
		}
	
	public void pintar(PApplet app,int y) {			//Pintar 3
		(Divertido).resize(100, 100);
		app.image (Divertido,x-10,y-50);
		}
	
	public void pintar (PApplet app, String stri1) {//Pintar 4
		(Triste).resize(100, 100);
		app.image (Triste,x1,y1-120);
		}
	
	public void pintar (PApplet app, String stri1, String stri2) {	//Pintar 5
		(Sorprendido).resize(100, 100);
		app.image (Sorprendido,x1,y1-120);
		}
	
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
	
}
