import processing.core.PApplet;
import processing.core.PImage;

public class Emoji {

	int x,y;
	PImage Enojado;
	PImage Enamorado;
	PImage Divertido;
	PImage Triste;
	PImage Sorprendido;
	
	public Emoji (PApplet app) {//Constructor
	this.Enojado=app.loadImage ("Enojado.png");
	this.Enamorado=app.loadImage ("Enamorado.png");
	this.Divertido=app.loadImage ("Divertido.png");
	this.Triste=app.loadImage ("Triste.png");
	this.Sorprendido=app.loadImage ("Sorprendido.png");
	
	this.x=210;
	this.y=200;
	}
	
	public void pintar(PApplet app) {//Pintar1
	app.rectMode(app.CENTER);
	app.image (Enojado,x-200,y);
	app.image (Enamorado,x-100,y);
	app.image (Divertido,x,y);
	app.image (Triste,x+100,y);
	app.image (Sorprendido,x+200,y);
	}
	
}
