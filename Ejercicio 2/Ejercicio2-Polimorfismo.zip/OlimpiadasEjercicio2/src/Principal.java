import processing.core.PApplet;
public class Principal extends PApplet{

	public static void main(String[] args) {
		PApplet.main("Principal");
		
	}
	
	@Override
	public void settings() {
		size(500,500);
	}
	int x, y;
	Emoji SmallEmoj; //Instancia para emojis peques
	BigEmoji BigEmoji; //Instancia para emoji grande
	Boolean Divertido;
	Boolean Enamorado;
	Boolean Enojado;
	Boolean Triste;
	Boolean Sorprendido;
	Boolean Boton;
	
	@Override
	public void setup() {
	x=250;
	y=400;
	SmallEmoj= new Emoji(this); //Instancia definida
	BigEmoji= new BigEmoji (this);
	Divertido=false;
	Enamorado=false;
	Enojado=false;
	Triste=false;
	Sorprendido=false;
	Boton=false;
	}
	
	@Override
	public void draw() {
	background(255);
	//BOTON
	rectMode(CENTER);
	noStroke();
	fill(0,200,255);
	rect(x, y, 150, 70,10);
	fill(255);
	textSize(25);
	text("Reaccionar", 185, 410);
	
	if (Boton==true) {	
	SmallEmoj.pintar(this); //Llamo instancia pintar de clase Emoji
	}
	
	if (Enojado==true) {					//Cara 1
		BigEmoji.pintar(this);
	}
	
	if (Enamorado==true) {					//Cara 2
		BigEmoji.pintar(this,200,130);
	}
	
	if (Divertido==true) {					//Cara 3
		BigEmoji.pintar(this,130);
	}
	
	if (Triste==true) {						//Cara 4
		BigEmoji.pintar(this,"");
	}
	
	if (Sorprendido==true) {				//Cara 5
		BigEmoji.pintar(this,"", "");
	}
	}

	@Override
	public void mousePressed() {
		if(dist(mouseX, mouseY,x,y)<40){
			Boton=true;
		}
		
		if(dist(mouseX, mouseY,BigEmoji.getX()-150,BigEmoji.getY()+50)<40){
			Enojado=true;
		} else {
			Enojado=false;
		}
		
		if(dist(mouseX, mouseY,BigEmoji.getX()-50,BigEmoji.getY()+50)<40){
			Enamorado=true;
		} else {
			Enamorado=false;
		}
		
		if(dist(mouseX, mouseY,BigEmoji.getX()+50,BigEmoji.getY()+50)<40){
			Divertido=true;
		} else {
			Divertido=false;
		}
		
		if(dist(mouseX, mouseY,BigEmoji.getX()+150,BigEmoji.getY()+50)<40){
			Triste=true;
		} else {
			Triste=false;
		}
		
		if(dist(mouseX, mouseY,BigEmoji.getX()+250,BigEmoji.getY()+50)<40){
			Sorprendido=true;
		} else {
			Sorprendido=false;
		}
	}
}