import processing.core.PApplet;

public class carro {

	int x;
	int y;
	int anc, lar;

	public carro() {
		this.x = 0;
		this.y = 230;
		this.anc = 30;
		this.lar = 40;
	}

	public carro(int x, int y, int anc, int lar) {
		this.x = x;
		this.y = y;
		this.anc = anc;
		this.lar = lar;
	}

	public void pintar(PApplet app) {
		app.noStroke();
		app.fill(255, 0, 0);
		app.rect(x, y, lar, anc);
	}
	
	public void pintarEnemy(PApplet app) {
		app.noStroke();
		app.fill(255, 255, 0);
		app.rect(x, y, lar, anc);
	}


	public void mover(String dir) {
		
	switch (dir) {
		case "arriba":
			this.y = y - 100;
			break;

		case "abajo":
			this.y = y + 100;
			break;

		case "atras":
			this.x = x - 10;
			break;

		case "delante":
			this.x = x + 10;
			break;
		}
	}

}
