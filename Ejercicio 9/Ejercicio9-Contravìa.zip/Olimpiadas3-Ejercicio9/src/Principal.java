import processing.core.PApplet;
import processing.core.PImage;

public class Principal extends PApplet {

	public static void main(String[] args) {
		PApplet.main("Principal");
	}

	public void settings() {
		size(1000, 500);

	}

	PImage fondo;
	carro car;
	carro[] yellowCar;
	int contador;
	int enemigos;
	boolean jugando;

	public void setup() {
		car = new carro();
		yellowCar = new carro[10];

		size(1000, 500);
		fondo = loadImage("carretera.jpg");
		
		jugando = false;

	}

	public void draw() {
		imageMode(CENTER);
		image(fondo, 500, 250, 1000, 500);
		car.pintar(this);
		
		if (jugando==false) {
			fill(0);
			textSize(50);
			text("Presiona i para iniciar", 200, 260);
		}

		if (jugando) {
			if (contador == 0) {
				int y = Math.round(random(5)) * 100 + 30;
				int x = 1000;
				carro enemy = new carro(x, y, 30, 40);

				enemy.pintarEnemy(this);
				yellowCar[enemigos] = enemy;

				if (enemigos < 9) {
					enemigos++;
				} else
					enemigos = 0;
			}
			
			for (int i = 0; i < yellowCar.length; i++) {
				if (yellowCar[i] != null) {
					yellowCar[i].pintarEnemy(this);
					yellowCar[i].mover("atras");
					if (yellowCar[i].y == car.y && (car.x >= yellowCar[i].x - 30 && car.x <= yellowCar[i].x + 30)) {
						jugando = false;
						yellowCar = new carro[10];
						car=new carro();
					}
				}
			}

			if (contador < 15) {
				contador++;
			} else
				contador = 0;
		}
		
	}

	public void keyPressed() {
		switch (key) {
		case 'w':
			if (car.y - 100 >= 0) {
				car.mover("arriba");
			}
			break;
		case 's':
			if (car.y + 100 <= 500) {
				car.mover("abajo");
			}
			break;
		case 'a':
			if (car.x - 10 >= 0) {
				car.mover("atras");
			}
			break;
		case 'd':
			if (car.x + 10 < 1000) {
				car.mover("delante");
			}
			break;
			
		case 'i':
			jugando = true;
			
			break;
		}
	}

}
