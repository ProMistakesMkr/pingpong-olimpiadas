import processing.core.PApplet;
import processing.core.PImage;

public class Principal extends PApplet {

	public static void main(String[] args) {
		PApplet.main("Principal");
	}
	
	@Override
	public void settings() {
		size(500,500);
	}
	
	int x, y;
	PImage cuerpo;
	Cuerno cuerno;
	Ala alas;				
	
	@Override
	public void setup() {
		x=270;
		y=270;
		alas = new Ala(220,180,this);
		cuerpo = loadImage("Dino.png");	
		cuerno = new Cuerno(170,80,this);
		
	}
	
	@Override
	public void draw() {
		background(random(0),random(0),random(100));
		alas.pintar(this);
		
		imageMode(CENTER);
		image(cuerpo, x, y);
		
		cuerno.pintar(this);
		
	}
}