import processing.core.PApplet;
import processing.core.PImage;

public class Cuerno {

		public int x;
		public int y;
		PImage cuerno;
	
		public Cuerno(int x, int y,PApplet app) {// constructor
			this.x = x;
			this.y = y;
			cuerno = app.loadImage("Cuerno.png");
		}
		
		public void pintar(PApplet app) { // app cuenta como objeto de PApplet
			app.image(cuerno, x, y);
		}
}
