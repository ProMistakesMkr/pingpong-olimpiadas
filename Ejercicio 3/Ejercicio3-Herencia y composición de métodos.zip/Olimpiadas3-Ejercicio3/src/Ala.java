import processing.core.PApplet;
import processing.core.PImage;

public class Ala extends Cuerno {
	public PImage Alas;
	
	public Ala(int x, int y, PApplet app) {
		super(x, y, app);
		Alas = app.loadImage("Alas.png");
	}

}
