import processing.core.PApplet;
import processing.core.PImage;

public class Usuario {
	private int tipodeusuario;
	private int x, y;

	private PImage usuario;
	private PApplet app;

	public Usuario(int tipodeusuario, int x, int y, PApplet app) {
		this.tipodeusuario = tipodeusuario;
		this.x = x;
		this.y = y;
		this.app = app;
		
		this.usuario = app.loadImage("U" + tipodeusuario + ".png");

	}

	public void pintar(){
		app.image(usuario, x, y,100,100);

	}
	
	public int getTipodeusuario() {
		return tipodeusuario;
	}
	
	public boolean click(){
		if(app.mouseX > x && app.mouseX< x + 100 && app.mouseY > y && app.mouseY < y+100){
			return true; 
		}
		return false;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	public void setY(int y) {
		this.y = y;
	}
	
}
