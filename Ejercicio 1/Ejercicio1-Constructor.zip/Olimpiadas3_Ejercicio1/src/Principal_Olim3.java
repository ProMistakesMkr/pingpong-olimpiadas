import java.util.ArrayList;

import processing.core.PApplet;

public class Principal_Olim3 extends PApplet {

	public static void main(String[] args) {

		PApplet.main("Principal_Olim3");
	}

	ArrayList usuarios = new ArrayList();
	Usuario seleccionado = null;
	public void settings() {
		size(500, 500);
	}

	public void setup() {
		usuarios.add(new Usuario(1, 50, 250, this));
		usuarios.add(new Usuario(2, 150, 250, this));
		usuarios.add(new Usuario(3, 250, 250, this));
		usuarios.add(new Usuario(4, 350, 250, this));
		
		
	}

	public void draw() {
		background(255, 255, 255);
		fill(0);
		textSize(20);
		text("Elige un usuario", 180, 50);
		textSize(15);
		text("User", 230, 100);
		for (int i = 0; i < usuarios.size(); i++) {
			((Usuario) usuarios.get(i)).pintar();
			
		}
		if (seleccionado != null){
			seleccionado.pintar();
			stroke(255,0,0);
			noFill();
			circle(250, 170, 100);
		}
		
	}
	public void mouseClicked(){
		for (int i = 0; i < usuarios.size(); i++) {
			if (((Usuario) usuarios.get(i)).click()){
				Usuario current =  (Usuario) usuarios.get(i);
			seleccionado = new Usuario (current.getTipodeusuario(),200,120,this);
		
			}
		}
	}
}