package View;

import processing.core.PApplet;

public class Screen1View {
	PApplet app;
	
	public Screen1View(PApplet app) {
		this.app = app;
		
	}
	
	public void dibujarFondo(){
		app.background(120,180,350);
		
		
	}

}
