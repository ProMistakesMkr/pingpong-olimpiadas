package View;

import processing.core.PApplet;

public class Screen3View {
PApplet app;
	
	public Screen3View(PApplet app) {
		this.app = app;
		
	}
	
	public void dibujarFondo(){
		app.background(350);
		
	}

}
