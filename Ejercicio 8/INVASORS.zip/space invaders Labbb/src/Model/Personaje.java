package Model;

public abstract class Personaje {
	private int posX;
	private int posY;

}
