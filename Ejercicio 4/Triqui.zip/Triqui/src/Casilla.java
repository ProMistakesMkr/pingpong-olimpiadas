import processing.core.PApplet;

public class Casilla {

	private int x, y, tipo, turno;

	public Casilla(int x, int y, int tipo) {
		this.x = x;
		this.y = y;
		this.tipo = tipo;
		this.turno = turno;
	}

	public void pintarCirculo(PApplet app) {
		app.rectMode(app.CENTER);
		app.noFill();
		app.stroke(255);
		app.strokeWeight(6);
		app.ellipse(x + 83, y + 83, 50, 50);
		app.rectMode(app.CORNER);
	}

	public void pintarEquis(PApplet app) {

		app.textAlign(app.CENTER, app.CENTER);
		app.textSize(75);
		app.text("X", x + 83, y + 83);
	}

	public void pintar(PApplet app) {
		app.noFill();
		app.stroke(100, 255, 75);
		app.strokeWeight(4);
		app.rect(x, y, 166, 166);

		switch (tipo) {
		case 1:
			pintarEquis(app);

			break;

		case 2:
			pintarCirculo(app);

			break;

		default:
			break;
		}
	}

	public boolean validar(int vx, int vy) {
		// <>
		if (vx > x && vx < x + 166 && vy > y && vy < y + 166) {
			return true;
		}
		return false;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

}
