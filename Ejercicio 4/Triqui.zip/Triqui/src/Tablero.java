import processing.core.PApplet;
import processing.core.PImage;

public class Tablero extends PApplet {

	public static void main(String[] args) {
		PApplet.main("Tablero");

	}

	public void settings() {
		size(500, 500);
	}

	Casilla[][] tablero;
	boolean turno;
	int turnoN; //1 o 2

	public void setup() {
		tablero = new Casilla[3][3];

		for (int f = 0; f < 3; f++) {
			for (int c = 0; c < 3; c++) {
				tablero[f][c] = new Casilla((f * 166), (c * 166), 0);
			}
		}
		turno = true;
		int turnoN = 1;
	}

	public void draw() {
		background(0);

		for (int f = 0; f < 3; f++) { // for para pintar las divisiones
			for (int c = 0; c < 3; c++) {

				tablero[f][c].pintar(this);
			}
		}

	}

	public void mouseClicked() {
		turno = !turno;
		
		if(turno == true) {
			turnoN =1;
		}
			if(turno == false){
			turnoN =2;
		}
			
		for (int f = 0; f < 3; f++) { // for para pintar las divisiones
			for (int c = 0; c < 3; c++) {

				if (tablero[f][c].validar(mouseX, mouseY)) {
					tablero[f][c].setTipo(turnoN);
				}
			
				System.out.println(turno);
	
			
			}
		}
	}
}
