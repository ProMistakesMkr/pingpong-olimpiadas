import processing.core.PApplet;
import processing.core.PImage;

public class Tablero extends PApplet {

	public static void main(String[] args) {
		PApplet.main("Tablero");

	}

	public void settings() {
		size(500, 500);
	}

	int[][] tablero;
     Jugador player1; 
     Jugador player2; 
	
	public void setup() {
    tablero = new int [3][3];
    player1 =  new Jugador(250,250);//equis
    player2 = new Jugador(250, 250);//circulo
    
    for (int f = 0; f < 3; f++) {  
		for (int c = 0; c < 3; c++) {
			tablero[f][c] = 0; 
		}
	
    }
    }

	public void draw() {
		background(0);

		for (int f = 0; f < 3; f++) {   //for para pintar las divisiones
			for (int c = 0; c < 3; c++) {
				
				int mx = 83 + (c * 166);
				int my = 83 + (f * 166);
				
				noFill();
				rectMode(CENTER);
				stroke(100, 255, 75);
				strokeWeight(4);
				rect(mx, my, 166, 166);
				rectMode(CORNER);
				
			}
			}
		
		player1.pintarEquis(this);
		player2.pintarCirculo(this);
	}

	
	public void mousePressed() {
		System.out.println(mouseX + "," + mouseY);
	}
}