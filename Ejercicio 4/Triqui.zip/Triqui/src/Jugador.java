import processing.core.PApplet;
import processing.core.PShapeSVG.Text;

public class Jugador {
   
	int x, y;
	
	public Jugador(int x, int y) {
		this.x = x;
		this.y = y;
		
	}
	public void pintarCirculo(PApplet app) {
        app.rectMode(app.CENTER);
	    app.noFill();
	    app.stroke(255);
	    app.strokeWeight(6);
	    app.ellipse(x, y, 50, 50);
	    app.rectMode(app.CORNER);
	}
	
	public void pintarEquis(PApplet app) {
		
		app.textAlign(app.CENTER, app.CENTER);
		app.textSize(75);
		app.text("X", x, y);
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
}
